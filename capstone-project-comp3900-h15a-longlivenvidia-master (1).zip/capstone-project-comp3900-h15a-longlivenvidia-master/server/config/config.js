const config = {
    productions: {
        SECRET: process.env.SECRET,
        DATABASE: process.env.MONGODB_URL,
    },
    default: {
        SECRET: "Fuckme32",
        DATABASE: "mongodb://localhost:27017/inv_sim",
    },
};

exports.get = function get(env) {
    return config[env] || config.default;
};
