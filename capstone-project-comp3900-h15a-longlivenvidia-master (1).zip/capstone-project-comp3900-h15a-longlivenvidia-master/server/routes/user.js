const express = require("express");
const router = express.Router();

// MIDDLEWARE
const { auth } = require("../middleware/auth");

// MODELS

const { User } = require("../models/user");

router.post("/register", (req, res) => {
    const user = new User(req.body);

    user.save((err, doc) => {
        if (err) {
            console.log(err);
            return res.json({ success: false });
        }
        res.status(200).json({
            success: true,
            user: doc,
        });
    });
});

router.post("/login", (req, res) => {
    User.findOne({ email: req.body.email }, (err, user) => {
        if (!user)
            return res.json({
                auth: false,
                message: "Auth fails, email not found",
                userData: false,
            });

        user.comparePassword(req.body.password, (err, isMatch) => {
            if (!isMatch)
                return res.json({
                    auth: false,
                    message: "Wrong password",
                    userData: false,
                });
            user.generateToken((err, user) => {
                if (err) return res.status(400).send(err);
                res.cookie("auth", user.token).json({
                    auth: true,
                    userData: {
                        id: user._id,
                        email: user.email,
                        firstName: user.firstName,
                        lastName: user.lastName,
                    },
                });
            });
        });
    });
});

router.get("/auth", auth, (req, res) => {
    res.json({
        auth: true,
        userData: {
            id: req.user._id,
            email: req.user.email,
            firstName: req.user.firstName,
            lastName: req.user.lastName,
        },
    });
});

router.get("/logout", auth, (req, res) => {
    req.user.deleteToken(req.token, (err, user) => {
        if (err) return res.status(400).send(err);
        res.status(200).send("You are logged out");
    });
});

router.post("/update", auth, (req, res) => {
    const user = req.user;
    user.firstName = req.body.firstName;
    user.lastName = req.body.lastName;
    user.email = req.body.email;
    if (req.body.password) user.password = req.body.password;
    user.save((err, doc) => {
        if (err) {
            if (err.name === "MongoError" && err.code === 11000) {
                return res.json({
                    success: false,
                    msg: "Email already existed",
                });
            }
            return res.json({
                success: false,
                msg: "Unknown error occurred",
            });
        }
        res.status(200).json({
            success: true,
            userData: {
                id: req.user._id,
                email: req.user.email,
                firstName: req.user.firstName,
                lastName: req.user.lastName,
            },
        });
    });
});

router.post("/search",auth, (req, res) =>{
    User.findOne({ email: req.body.email }, (err, user) => {
        if (!user){
            return res.json({
                success: false,
                message: "No user found with this email address",
            })
        }
        res.status(200).json({
            success: true,
            searchedUserData: {
                firstName: user.firstName,
                lastName: user.lastName,
                email: user.email,
            },
        });
    });
});

module.exports = router;
