const finnhub = require('finnhub');
const express = require("express");
const router = express.Router();

// MIDDLEWARE
const { auth } = require("../middleware/auth");
const { compareSync } = require('bcrypt');
const { User } = require("../models/user");

// API client
const api_key = finnhub.ApiClient.instance.authentications['api_key'];
api_key.apiKey = "bu25dmn48v6uohspupag" // this is the api key from my account
const finnhubClient = new finnhub.DefaultApi()

router.post("/searchstock",auth, (req, res) => {
	const s = req.body.searchword;
	finnhubClient.companyProfile2({'symbol': s}, (error, data, response) => {
		if (error || Object.entries(data).length === 0){
			return res.json({
				success: false,
				message: "No Stock Exists",
			});
		}
		res.status(200).json({
			success: true,
			search: {
				name: data.name,
				logo:data.logo,
				industry: data.finnhubIndustry,
			},
		});
	})
})

router.post("/searchprice",auth, (req, res) => {
	const s = req.body.searchword;
	finnhubClient.quote(s, (error, data, response) => {
		if (error || Object.entries(data).length === 0){
			return res.json({
				success: false,
				message: "No Stock Exists",
			});
		}
		res.status(200).json({
			success: true,
			price: {
				pcurr:data.c,
				popen:data.o,
				phigh:data.h,
				plow: data.l,
				pprev: data.pc,
			},
		});
	})
})

router.post("/searchsymbol",auth, (req, res) => {
	const s = req.body.searchword;
	const request = require('request');

	request('http://d.yimg.com/aq/autoc?query='+ s + '&region=IN&lang=en-UK&callback=YAHOO.Finance.SymbolSuggest.ssCallback', (err, response, body) => {
  		if (err) { 
			return res.json({
				success: false,
				message: "No Stock Exists",
			}); 
		}
  		let s = body.slice(39);
  		let i = s.replace(");",'');
  		const j = JSON.parse(i);
		const d = j.ResultSet.Result;
		if (Object.entries(d).length === 0){
			return res.json({
				success: false,
				message: "No Stock Exists",
			}); 
		}
  		res.status(200).json({
			success: true,
			search: {
				nearmatches:d,
			},
		});
	})
})

module.exports = router;