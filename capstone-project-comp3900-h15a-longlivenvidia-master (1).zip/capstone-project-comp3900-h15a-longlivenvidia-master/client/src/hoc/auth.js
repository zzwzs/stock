import React, { Component } from "react";
import { auth } from "../store/actions/user_actions";
import { connect } from "react-redux";

export default function (ComposedClass, reload) {
    class AuthenticationCheck extends Component {
        state = {
            loading: true,
        };

        componentDidMount() {
            this.props
                .dispatch(auth())
                .then((response) => {
                    let user = this.props.user.auth;

                    this.setState({ loading: false });
                    if (!user) {
                        this.props.history.push("/login");
                    } else {
                        this.props.history.push("/");
                    }
                })
                .catch((err) => {
                    console.log(err);
                });
        }

        render() {
            if (this.state.loading) {
                return <div>Loading...</div>;
            }
            return <ComposedClass {...this.props} user={this.props.user} />;
        }
    }

    function mapStateToProps(state) {
        return {
            user: state.user,
        };
    }

    return connect(mapStateToProps)(AuthenticationCheck);
}
