import React from "react";
import ReactDOM from "react-dom";
import App from "./App";
import { ThemeContextProvider } from "./components/sidebar/Menu/ToggleSwitch/themeContext";

import { Provider } from "react-redux";
import { createStore, applyMiddleware, compose } from "redux";
import promiseMiddleware from "redux-promise";

import reducers from "./store/reducers";

// const createStoreWithMiddleware = applyMiddleware(promiseMiddleware)(
//     createStore
// );
const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;
const store = createStore(
    reducers,
    /* preloadedState, */ composeEnhancers(applyMiddleware(promiseMiddleware))
);

ReactDOM.render(
    <Provider store={store}>
        <ThemeContextProvider>
            <App />
        </ThemeContextProvider>
    </Provider>,
    document.getElementById("root")
);
