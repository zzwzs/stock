import React from "react";
import styled from "styled-components";
import { connect } from "react-redux";
import UserAvatar from "react-user-avatar";

const Container = styled.div`
    display: flex;
    padding: 0.5rem;
    justify-content: flex-end;
    align-items: center;
    margin-top: 0.2 rem;
`;

const ProfileImg = styled(UserAvatar)`
    transform: scale(0.6);
    display: flex;
    justify-content: center;
    align-items: center;
    height: 2rem;
    margin: 0 1rem;
    cursor: pointer;
    border-radius: 50%;
`;

const MessageIcon = styled.span`
    color: ${({ theme }) => theme.colorGray};
    font-size: 27px;
    cursor: pointer;
`;

const Navbar = (props) => {
    return (
        <Container>
            <MessageIcon
                className="iconify"
                data-inline="false"
                data-icon="mdi-light:email"
            ></MessageIcon>
            <ProfileImg
                size="49"
                name={
                    props.user.userData.firstName +
                    " " +
                    props.user.userData.lastName
                }
            />
        </Container>
    );
};

const mapStateToProps = (state) => ({
    user: state.user,
});

export default connect(mapStateToProps)(Navbar);
