import React from "react";
import styled from "styled-components";
import { connect } from "react-redux";
import UserAvatar from "react-user-avatar";

const Container = styled.div`
    margin-top: 1rem;
    align-items: center;
`;

const ProfileImg = styled(UserAvatar)`
    display: flex;
    justify-content: center;
    align-items: center;
    transform: ${({ sideBarOpen }) =>
        sideBarOpen ? "scale(1)" : "scale(0.5)"};
    transition: transform 0.3s;
    border-radius: 50%;
    margin-left: auto;
    margin-right: auto;
    @media (max-width: 700px) {
        transform: ${({ sideBarOpen }) =>
            sideBarOpen ? "scale(0.5)" : "scale(1)"};
        transition: transform 0.3s;
    }
`;

const ProfileName = styled.h1`
    display: block;
    opacity: ${({ sideBarOpen }) => (sideBarOpen ? "1" : "0")};
    transition: opacity 0.3s;
    font-size: 1rem;
    font-weight: 300;
    color: ${({ theme }) => theme.textColor};
    white-space: nowrap;
    overflow: hidden;
    @media (max-width: 700px) {
        opacity: ${({ sideBarOpen }) => (sideBarOpen ? "0" : "1")};
        transition: opacity 0.3s;
    }
`;

const Profile = (props) => {
    return (
        <Container>
            <ProfileImg
                sideBarOpen={props.sideBarState.sideBarOpen}
                size="69"
                name={
                    props.user.userData.firstName +
                    " " +
                    props.user.userData.lastName
                }
            />
        </Container>
    );
};

const mapStateToProps = (state) => ({
    user: state.user,
});

export default connect(mapStateToProps)(Profile);
