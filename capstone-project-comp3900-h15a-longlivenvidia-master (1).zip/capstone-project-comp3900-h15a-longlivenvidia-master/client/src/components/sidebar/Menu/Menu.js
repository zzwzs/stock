import React from "react";
import MenuLink from "./MenuLink";
import styled from "styled-components";
import ToggleSwitch from "./ToggleSwitch/ToggleSwitch";
import { Link } from "react-router-dom";

const Container = styled.div`
    margin-top: 2rem;
    width: 100%;
`;

const Hamburger = styled.div`
    display: flex;
    flex-direction: column;
    cursor: pointer;
    position: absolute;
    top: 1.1rem;
    right: 1.2rem;
    span {
        height: 2px;
        width: 23px;
        background: ${(props) => props.theme.main};
        margin-bottom: 4px;
        border-radius: 5px;
    }
`;

const Menu = ({ active, activate, sideBarState }) => {
    return (
        <Container>
            <MenuLink
                id={0}
                title="Dashboard"
                icon={"home"}
                active={active}
                activate={() => activate(0)}
                sideBarState={sideBarState}
            />
            <MenuLink
                id={1}
                title="Search"
                icon={"magnify"}
                active={active}
                activate={() => activate(1)}
                sideBarState={sideBarState}
            />
            <MenuLink
                id={2}
                title="Watchlist"
                icon={"eye"}
                active={active}
                activate={() => activate(2)}
                sideBarState={sideBarState}
            />
            <MenuLink
                id={3}
                title="Settings"
                icon={"cog"}
                active={active}
                activate={() => activate(3)}
                sideBarState={sideBarState}
            />
            <Link
                to="/logout"
                style={{ textDecoration: "none", color: "inherit" }}
            >
                <MenuLink
                    id={4}
                    title="Logout"
                    icon={"logout"}
                    active={active}
                    activate={() => activate(4)}
                    sideBarState={sideBarState}
                />
            </Link>
            <Hamburger
                onClick={() =>
                    sideBarState.setSideBarOpen(!sideBarState.sideBarOpen)
                }
            >
                <span />
                <span />
                <span />
            </Hamburger>
            <ToggleSwitch />
        </Container>
    );
};

export default Menu;
