import React from "react";
import styled from "styled-components";
import Menu from "./Menu/Menu";
import Profile from "./Profile";

const Container = styled.div`
    background-color: ${({ theme }) => theme.secondary};
    position: fixed;
    left: 0;
    top: 0;
    bottom: 0;
    width: ${({ sideBarState }) =>
        sideBarState.sideBarOpen
            ? sideBarState.sideBarFullLength
            : sideBarState.sideBarHiddenLength};
    transition: width 0.3s;
    display: flex;
    flex-direction: column;
    align-items: center;
    @media (max-width: 700px) {
        overflow: hidden;
        height: 100%;
        width: ${({ sideBarState }) =>
            sideBarState.sideBarOpen
                ? sideBarState.sideBarHiddenLength
                : sideBarState.sideBarFullLength};
        transition: width 0.3s;
    }
`;

const Brand = styled.h1`
    opacity: ${({ sideBarState }) => (sideBarState.sideBarOpen ? "1" : "0")};
    transition: opacity 0.3s;
    white-space: nowrap;
    overflow: hidden;
    font-size: 1.3rem;
    font-weight: 1000;
    color: ${({ theme }) => theme.textColor};
    @media (max-width: 700px) {
        opacity: ${({ sideBarState }) =>
            sideBarState.sideBarOpen ? "0" : "1"};
        transition: opacity 0.3s;
    }
`;

const Sidebar = ({ active, activate, sideBarState }) => {
    return (
        <div>
            <Container sideBarState={sideBarState}>
                <Brand sideBarState={sideBarState}>Inv Sim</Brand>
                <Profile sideBarState={sideBarState} />
                <Menu
                    active={active}
                    activate={activate}
                    sideBarState={sideBarState}
                />
            </Container>
        </div>
    );
};

export default Sidebar;
