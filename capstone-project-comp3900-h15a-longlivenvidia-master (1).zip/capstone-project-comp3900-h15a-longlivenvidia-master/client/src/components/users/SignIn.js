import React, { Component } from "react";
import { Formik } from "formik";
import * as Yup from "yup";
import styled from "styled-components";
import { loginUser } from "../../store/actions/user_actions";
import { connect } from "react-redux";

const Label = styled.h1`
    color: white;
    margin-bottom: 49px;
    display: block;
    font-size: 39px;
    line-height: 1;
    text-align: center;
    color: #fff;
`;

const Input = styled.input`
    border: 0;
    background: none;
    display: block;
    margin: 20px auto;
    text-align: center;
    border: 2px solid #36f9f6;
    padding: 14px 10px;
    width: 200px;
    outline: none;
    color: white;
    border-radius: 24px;
    transition: 0.25s;
    &:focus {
        width: 230px;
        border-color: #ff7edb;
    }
`;

const ButtonContainer = styled.div`
    width: 100%;
    padding: 2px 0;
`;

const Button = styled.button`
    border: 0;
    background: none;
    display: block;
    margin: 20px auto;
    text-align: center;
    border: 2px solid #ff7edb;
    padding: 14px 40px;
    outline: none;
    color: white;
    border-radius: 24px;
    transition: 0.25s;
    cursor: pointer;
    &: hover {
        background: #ff7edb;
    }
`;

const Span = styled.span`
    color: yellow;
    font-weight: 500;
    letter-spacing: 0.5px;
    margin-left: 5px;
    cursor: pointer;
    transition: all 400ms ease-in-out;
`;

const P = styled.p`
    margin: 14px 0 0 0;
    text-align: center;
    color: #fff;
`;

const Error = styled.p`
    margin: 14px 0 0 0;
    text-align: center;
    color: #e9414d;
`;

const SignInSchema = Yup.object().shape({
    password: Yup.string().min(6, "Too short!!").required("Required!!!"),
    email: Yup.string().email("Invalid email").required("Required!!!"),
});

class SignIn extends Component {
    state = {
        success: false,
        validation: false,
    };

    static getDerivedStateFromProps(props, state) {
        const auth = props.user.auth;
        if (auth) {
            return {
                success: auth ? true : false,
            };
        }
        return null;
    }

    componentDidUpdate() {
        if (this.state.success) {
            this.props.history.push("/");
        }
    }
    render() {
        return (
            <div>
                <Formik
                    initialValues={{
                        email: "minqz2009@gmail.com",
                        password: "Fuckyou",
                    }}
                    validationSchema={SignInSchema}
                    onSubmit={(values) => {
                        this.props
                            .dispatch(loginUser(values))
                            .then((response) => {
                                if (!this.props.user.auth) {
                                    this.setState({
                                        validation: true,
                                    });
                                }
                            });
                    }}
                >
                    {({
                        values,
                        errors,
                        touched,
                        handleChange,
                        handleBlur,
                        handleSubmit,
                    }) => (
                        <form onSubmit={handleSubmit}>
                            <Label>Login</Label>
                            <Input
                                type="email"
                                name="email"
                                onChange={handleChange}
                                onBlur={handleBlur}
                                value={values.email}
                                placeholder="Enter your email"
                                autoFocus
                                required
                            />
                            {errors.email && touched.email ? (
                                <>{errors.email}</>
                            ) : null}
                            <Input
                                type="password"
                                name="password"
                                onChange={handleChange}
                                onBlur={handleBlur}
                                value={values.password}
                                placeholder="Enter your password"
                                autoFocus
                                required
                            />
                            {errors.password && touched.password ? (
                                <div>{errors.password}</div>
                            ) : null}
                            <ButtonContainer>
                                <Button type="submit">Sign in</Button>
                                <P>
                                    Don't have an account?
                                    <Span
                                        onClick={() =>
                                            this.props.setHasAccount(
                                                !this.props.hasAccount
                                            )
                                        }
                                    >
                                        Sign up
                                    </Span>
                                </P>
                            </ButtonContainer>
                            {this.state.validation ? (
                                <Error>Incorrect email or password</Error>
                            ) : null}
                        </form>
                    )}
                </Formik>
            </div>
        );
    }
}

function mapStateToProps(state) {
    return {
        user: state.user,
    };
}

export default connect(mapStateToProps)(SignIn);
