import React, { Component } from "react";
import styled from "styled-components";
import { Formik } from "formik";
import * as Yup from "yup";
import { loginUser, registerUser } from "../../store/actions/user_actions";

const Input = styled.input`
    border: 0;
    background: none;
    display: block;
    margin: 20px auto;
    text-align: center;
    border: 2px solid #36f9f6;
    padding: 14px 10px;
    width: 200px;
    outline: none;
    color: white;
    border-radius: 24px;
    transition: 0.25s;
    &:focus {
        width: 230px;
        border-color: #ff7edb;
    }
`;

const ButtonContainer = styled.div`
    width: 100%;
    padding: 2px 0;
`;

const Button = styled.button`
    border: 0;
    background: none;
    display: block;
    margin: 20px auto;
    text-align: center;
    border: 2px solid #ff7edb;
    padding: 14px 40px;
    outline: none;
    color: white;
    border-radius: 24px;
    transition: 0.25s;
    cursor: pointer;
    &: hover {
        background: #ff7edb;
    }
`;

const Span = styled.span`
    color: yellow;
    font-weight: 500;
    letter-spacing: 0.5px;
    margin-left: 5px;
    cursor: pointer;
    transition: all 400ms ease-in-out;
`;

const Error = styled.p`
    margin: 14px 0 0 0;
    text-align: center;
    color: #e9414d;
`;

const P = styled.p`
    margin: 14px 0 0 0;
    text-align: center;
    color: #fff;
`;

const SignUpSchema = Yup.object().shape({
    firstName: Yup.string().min(1, "Too short!!").required("Required!!!"),
    lastName: Yup.string().min(1, "Too short!!").required("Required!!!"),
    email: Yup.string().email("Invalid email").required("Required!!!"),
    password: Yup.string().min(6, "Too short!!").required("Required!!!"),
    reenterPassword: Yup.string().oneOf(
        [Yup.ref("password"), null],
        "Passwords must match"
    ),
});

class SignUp extends Component {
    state = {
        success: false,
        validation: false,
    };

    static getDerivedStateFromProps(props, state) {
        const auth = props.user.auth;
        if (auth) {
            return {
                success: auth ? true : false,
            };
        }
        return null;
    }

    componentDidUpdate() {
        console.log("signup");
        if (this.state.success) {
            this.props.setHasAccount(true);
            this.props.history.push("/");
        }
    }
    render() {
        return (
            <div>
                <Formik
                    initialValues={{
                        firstName: "Wu",
                        lastName: "Jiakang",
                        email: "minqz2009@gmal.com",
                        password: "Fuckyou",
                    }}
                    validationSchema={SignUpSchema}
                    onSubmit={(values) => {
                        this.props
                            .dispatch(registerUser(values))
                            .then((response) => {
                                if (!this.props.user.success) {
                                    this.setState({
                                        validation: true,
                                    });
                                } else {
                                    this.props.dispatch(loginUser(values));
                                }
                            });
                    }}
                >
                    {({
                        values,
                        errors,
                        touched,
                        handleChange,
                        handleBlur,
                        handleSubmit,
                    }) => (
                        <form onSubmit={handleSubmit}>
                            <Input
                                type="firstName"
                                name="firstName"
                                onChange={handleChange}
                                onBlur={handleBlur}
                                value={values.firstName}
                                placeholder="Enter your first name"
                                autoFocus
                                required
                            />
                            {errors.firstName && touched.firstName ? (
                                <Error>{errors.firstName}</Error>
                            ) : null}
                            <Input
                                type="lastName"
                                name="lastName"
                                onChange={handleChange}
                                onBlur={handleBlur}
                                value={values.lastName}
                                placeholder="Enter your lastName"
                                autoFocus
                                required
                            />
                            {errors.lastName && touched.lastName ? (
                                <Error>{errors.lastName}</Error>
                            ) : null}
                            <Input
                                type="email"
                                name="email"
                                onChange={handleChange}
                                onBlur={handleBlur}
                                value={values.email}
                                placeholder="Enter your email"
                                autoFocus
                                required
                            />
                            {errors.email && touched.email ? (
                                <Error>{errors.email}</Error>
                            ) : null}
                            <Input
                                type="password"
                                name="password"
                                onChange={handleChange}
                                onBlur={handleBlur}
                                value={values.password}
                                placeholder="Enter your password"
                                autoFocus
                                required
                            />
                            {errors.password && touched.password ? (
                                <Error>{errors.password}</Error>
                            ) : null}
                            <Input
                                type="password"
                                name="reenterPassword"
                                onChange={handleChange}
                                onBlur={handleBlur}
                                // value={}
                                placeholder="Re-enter your password"
                                autoFocus
                                required
                            />
                            {errors.reenterPassword &&
                            touched.reenterPassword ? (
                                <Error>{errors.reenterPassword}</Error>
                            ) : null}
                            <ButtonContainer>
                                <Button type="submit">Sign up</Button>
                                <P>
                                    Have an account?
                                    <Span
                                        onClick={() =>
                                            this.props.setHasAccount(
                                                !this.props.hasAccount
                                            )
                                        }
                                    >
                                        Sign in
                                    </Span>
                                </P>
                            </ButtonContainer>
                            {this.state.validation ? (
                                <Error>Email already registered</Error>
                            ) : null}
                        </form>
                    )}
                </Formik>
            </div>
        );
    }
}
export default SignUp;
