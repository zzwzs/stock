import React, { useState } from "react";
import { CSSTransition } from "react-transition-group";
import styled from "styled-components";
import Image from "../../../assets/images/pi.jpg";
import { connect } from "react-redux";
import { Formik } from "formik";
import * as Yup from "yup";
import { updateUser } from "../../../store/actions/user_actions";
import UserAvatar from "react-user-avatar";

const Container = styled.div`
    margin-top: 1rem;
`;

const Label = styled.h2`
    display: block;
    text-align: center;
`;

const Input = styled.input`
    border: 0;
    background: none;
    display: block;
    margin: 20px auto;
    text-align: center;
    border: ${({ disabled }) =>
        disabled ? "2px solid #42a5f5" : "2px solid #36f9f6"};
    border: ;
    padding: 14px 10px;
    width: ${({ disabled }) => (disabled ? "200px" : "260px")};
    outline: none;
    color: ${({ theme }) =>
        console.log(theme) ? theme.textColor : theme.textColor};
    border-radius: 24px;
    transition: 0.25s;
    &:focus {
        width: 230px;
        border-color: #ff7edb;
    }
`;

const ButtonContainer = styled.div`
    width: 100%;
    padding: 2px 0;
    display: flex;
    align-items: center;
`;

const Button = styled.button`
    border: 0;
    background: none;
    margin: 20px auto;
    text-align: center;
    border: 2px solid #ff7edb;
    padding: 14px 40px;
    outline: none;
    color: ${({ theme }) => theme.textColor};
    border-radius: 24px;
    transition: 0.25s;
    cursor: pointer;
    &: hover {
        background: #ff7edb;
    }
`;

const ProfileImg = styled(UserAvatar)`
    display: flex;
    justify-content: center;
    align-items: center;
    height: 8rem;
    border-radius: 50%;
    margin-left: auto;
    margin-right: auto;
`;

const Notification = styled.p`
    margin: 14px 0 0 0;
    text-align: center;
    color: ${({ error }) => (error ? "#e9414d" : "#4caf50")};
`;

const SettingsSchema = Yup.object().shape({
    firstName: Yup.string().min(1, "Too short!!").required("Required!!!"),
    lastName: Yup.string().min(1, "Too short!!").required("Required!!!"),
    email: Yup.string().email("Invalid email").required("Required!!!"),
    password: Yup.string().min(6, "Too short!!"),
    reenterPassword: Yup.string().oneOf(
        [Yup.ref("password"), null],
        "Passwords must match"
    ),
});

const Settings = (props) => {
    const [disabled, setDisabled] = useState(true);
    const [showSuccess, setShowSuccess] = useState(false);
    const [showFail, setShowFail] = useState(false);
    const [failMsg, setFailMsg] = useState("");

    return (
        <CSSTransition in={true} appear={true} timeout={500} classNames="fade">
            <Container>
                <Label>Settings</Label>
                <ProfileImg
                    size="109"
                    name={
                        props.user.userData.firstName +
                        " " +
                        props.user.userData.lastName
                    }
                />

                <Formik
                    initialValues={{
                        firstName: props.user.userData.firstName,
                        lastName: props.user.userData.lastName,
                        email: props.user.userData.email,
                    }}
                    validationSchema={SettingsSchema}
                    onSubmit={(values) => {
                        setShowFail(false);
                        setFailMsg("");
                        props.dispatch(updateUser(values)).then((response) => {
                            if (response.payload.success) {
                                setDisabled(true);
                                setShowSuccess(true);
                                setTimeout(() => {
                                    setShowSuccess(false);
                                }, 3000);
                            } else {
                                console.log(response.payload);
                                setShowFail(true);
                                setFailMsg(response.payload.msg);
                            }
                        });
                    }}
                >
                    {({
                        values,
                        errors,
                        touched,
                        handleChange,
                        handleBlur,
                        handleSubmit,
                    }) => (
                        <form onSubmit={handleSubmit}>
                            <Input
                                type="firstName"
                                name="firstName"
                                onChange={handleChange}
                                onBlur={handleBlur}
                                value={values.firstName}
                                disabled={disabled}
                                autoFocus
                                required
                            />
                            {errors.firstName && touched.firstName ? (
                                <Notification error={true}>
                                    {errors.firstName}
                                </Notification>
                            ) : null}
                            <Input
                                type="lastName"
                                name="lastName"
                                onChange={handleChange}
                                onBlur={handleBlur}
                                value={values.lastName}
                                disabled={disabled}
                                autoFocus
                                required
                            />
                            {errors.lastName && touched.lastName ? (
                                <Notification error={true}>
                                    {errors.lastName}
                                </Notification>
                            ) : null}
                            <Input
                                type="email"
                                name="email"
                                onChange={handleChange}
                                onBlur={handleBlur}
                                value={values.email}
                                disabled={disabled}
                                autoFocus
                                required
                            />
                            {errors.email && touched.email ? (
                                <Notification error={true}>
                                    {errors.email}
                                </Notification>
                            ) : null}
                            <Input
                                type="password"
                                name="password"
                                onChange={handleChange}
                                onBlur={handleBlur}
                                placeholder="Enter your new password"
                                disabled={disabled}
                                autoFocus
                            />
                            {errors.password && touched.password ? (
                                <Notification error={true}>
                                    {errors.password}
                                </Notification>
                            ) : null}
                            <Input
                                type="password"
                                name="reenterPassword"
                                onChange={handleChange}
                                onBlur={handleBlur}
                                placeholder="Re-enter your new password"
                                disabled={disabled}
                                autoFocus
                            />
                            {errors.reenterPassword &&
                            touched.reenterPassword ? (
                                <Notification error={true}>
                                    {errors.reenterPassword}
                                </Notification>
                            ) : null}
                            <Notification error={showFail}>
                                {showFail
                                    ? failMsg
                                    : showSuccess
                                    ? "Successfully updated"
                                    : ""}
                                {}
                            </Notification>
                            <ButtonContainer>
                                <Button
                                    type="button"
                                    onClick={(event) => setDisabled(false)}
                                >
                                    Change
                                </Button>
                                <Button type="submit">Save</Button>
                            </ButtonContainer>
                        </form>
                    )}
                </Formik>
            </Container>
        </CSSTransition>
    );
};

const mapStateToProps = (state) => ({
    user: state.user,
});

export default connect(mapStateToProps)(Settings);
