import React from "react";
import { CSSTransition } from "react-transition-group";
import Chart from "./Chart";
import Tilt from "react-tilt";
import styled from "styled-components";

const Container = styled.div`
    width: 100%;
    padding: 0.3rem;
    padding-left: 1.46rem;
    cursor: pointer;
    display: flex;
    flex-direction: column;
    align-items: center;
`;

const Card = styled.div`
    display: flex;
    border-radius: 10px;
    border: 1px solid;
    padding: 1px;
    left: 1rem;
`;
const Titile = styled.div`
    text-align: center;
    margin: auto;
    width: 50%;
    padding: 1px;
`;

const Dashboard = () => {
    return (
        <CSSTransition in={true} appear={true} timeout={500} classNames="fade">
            <Container>
                <Titile>
                    <h2>Dashboard</h2>
                </Titile>
                <Tilt
                    className="Tilt"
                    options={{ max: 9, scale: 1.02 }}
                    style={{ height: 130, width: 300 }}
                >
                    <Card>
                        <Chart />
                    </Card>
                </Tilt>
            </Container>
        </CSSTransition>
    );
};

export default Dashboard;
