import React from "react";
import styled from "styled-components";
import UserAvatar from "react-user-avatar";

const Backbutton = styled.button`
    outline: none;
    border: 0;
    background: none;
    font-size: 1.2em;
    color: ${({ theme }) => theme.textColor};
    float: left;
    position: absolute;
    cursor: pointer;
`;

const Div = styled.div`
    text-align: center;
    margin: 5%;
    padding: 5px 30px;
`;

const ProfileImg = styled(UserAvatar)`
    display: flex;
    justify-content: center;
    align-items: center;
    height: 8rem;
    border-radius: 50%;
    margin-left: auto;
    margin-right: auto;
`;

const UserProfile = ({firstName, lastName, email, onClickaction}) => {
    return (
        <div>
            <Backbutton onClick={onClickaction}>&laquo; Back</Backbutton>
            <Div>
                <ProfileImg
                        size="109"
                        name={
                            firstName +
                            " " +
                            lastName
                        }
                    />
                <h2>{firstName}   {lastName}</h2>
                <p>{email}</p>
            </Div>
        </div>
    );
}
  
export default UserProfile; 
