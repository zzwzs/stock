import React, { Component } from "react";
import { CSSTransition } from "react-transition-group";
import styled from "styled-components";
import { connect } from "react-redux";
import { searchStock, searchSymbol, searchPrice} from "../../../store/actions/finnhub_actions";
import { searchUser } from "../../../store/actions/user_actions";
import StockResult from "./StockResult";
import UserResult from "./UserResult";
import UserProfile from "./UserProfile";

const Container = styled.div`
    margin-top: 1rem;
`;

const Button = styled.button`
    position: absolute;
    border: 0;
    background: none;
    margin: 20px 10px;
    text-align: center;
    border: 2px solid #ff7edb;
    padding: 14px 20px;
    outline: none;
    color: ${({ theme }) => theme.textColor};
    border-radius: 24px;
    transition: 0.25s;
    cursor: pointer;
    &: hover {
        background: #ff7edb;
    }
`;

const Input = styled.input`
    border: 0;
    background: none;
    width: 80%
    display: block;
    margin: 20px auto;
    border: ${({ disabled }) =>
        disabled ? "2px solid #42a5f5" : "2px solid #36f9f6"};
    padding: 14px 10px;
    width: ${({ disabled }) => (disabled ? "40%" : "40%")};
    outline: none;
    color: ${({ theme }) =>
        theme ? theme.textColor : theme.textColor};
    border-radius: 24px;
    transition: 0.25s;
    &:focus {
        width: 50%;
        border-color: #ff7edb;
    }
`;
const RadioContainer = styled.div`
    display:flex;
    flex-direction:row;
    width: 40%;
    margin: auto;
`;
const Radio = styled.div`
    flex: 1;
    text-align: center;
`;

const Center = styled.div`
    text-align: center;
`;

const H2 = styled.h2`
    margin: 20%;
`;

const SearchIcon = styled.div`
    font-size: 40px;
    postion: absolute;
    bottom:2px;
    right:5px;
    width:24px;
    height:24px;
`;

class Search extends Component {
    constructor(){
        super();
        this.state = {
           displayresult : [],
           hide: false,
           selectedOption: "stockName",
        };
        this.onValueChange = this.onValueChange.bind(this);
        this.formSubmit = this.formSubmit.bind(this);
        this.search = this.search.bind(this);
        this.handleChildClick=this.handleChildClick.bind(this);
        this.handleChildClickBack = this.handleChildClickBack.bind(this);
    }
    handleChildClick() {
        this.setState({hide: true});
    }
    handleChildClickBack() {
        this.setState({hide: false});
    }
    onValueChange (event){
        this.setState({
          selectedOption: event.target.value
        });
    }
    formSubmit(event) {
        event.preventDefault();
    }

    search (event) {
        const searchString = this.state.searchString;
        this.setState({
            displayresult: [],
        })
        if (this.state.selectedOption === "userEmail"){
            this.props
            .dispatch(searchUser(searchString))
            .then((res) => {
                this.setState({
                    currSearchOption: this.state.selectedOption,
                    msg: this.props.user.success? false: res.payload.message,
                })
                
                if (this.props.user.success){
                    this.setState({
                        displayresult: [...this.state.displayresult, 
                        <UserResult 
                            firstName = {this.props.user.searchedUserData.firstName}
                            lastName = {this.props.user.searchedUserData.lastName}
                            email = {this.props.user.searchedUserData.email}
                            onClickaction = {this.handleChildClick}
                        /> ]
                    })
                }
            })

        }else{
            this.props
            .dispatch(searchSymbol(searchString))
            .then((res)=>{
                this.setState({
                    currSearchOption: this.state.selectedOption,
                    msg: this.props.finnhub.success? false: res.payload.message,
                }) 
                if (!this.props.finnhub.success) return;
                
                for (const stock of this.props.finnhub.search.nearmatches){
                    this.props
                    .dispatch(searchPrice(stock.symbol))
                    .then(()=>{
                        if (this.props.finnhub.price){
                            this.state.displayresult.push(
                                <StockResult 
                                    companyName ={stock.name}
                                    symbol = {stock.symbol}
                                    price = {this.props.finnhub.price}
                                />
                            )
                        }
                    })
                }
            })
        }
    }

    render () {   
        return (
            <CSSTransition in={true} appear={true} timeout={500} classNames="fade">
                <Container>
                    <form onSubmit={this.formSubmit}>        
                        <Center>

                        <Input 
                            type="text" 
                            placeholder={
                                this.state.selectedOption === "userEmail" ?
                                "Enter email address to search user": "Enter stock code or stock name to search stock"
                            } 
                            aria-label="Search"
                            onChange = {(event) => {
                                this.setState({
                                    searchString: event.target.value,
                                });
                            }}
                        >    
                        </Input>
                        <Button type="submit" onClick={this.search}>
                            Search
                        </Button>

                        </Center>
                        <RadioContainer>
                            <Radio>
                                <label>
                                    <input
                                    type="radio"
                                    value="stockName"
                                    name="method"
                                    checked={this.state.selectedOption === "stockName"}
                                    onChange={this.onValueChange}
                                    />
                                    By stock
                                </label>
                            </Radio>
                            <Radio>
                                <label>
                                    <input
                                    type="radio"
                                    value="userEmail"
                                    name="method"
                                    checked={this.state.selectedOption === "userEmail"}
                                    onChange={this.onValueChange}
                                    />
                                    By user
                                </label>
                            </Radio>
                        </RadioContainer>
                    </form>

                    {this.state.hide ? 
                        // hide state: individual stock or user page
                        (this.state.currSearchOption === 'userEmail' &&
                        <UserProfile
                        firstName = {this.props.user.searchedUserData.firstName}
                        lastName = {this.props.user.searchedUserData.lastName}
                        email = {this.props.user.searchedUserData.email}
                        onClickaction = {this.handleChildClickBack}
                        />
                        )
                    :
                        <div>{this.state.displayresult}</div>  
                    }

                    {this.state.msg?<Center><H2>{this.state.msg}</H2></Center>:null}
                    
                </Container>
            </CSSTransition>
        );
    }

};

const mapStateToProps = (state) => ({
    user: state.user,
    finnhub: state.finnhub
});

export default connect(mapStateToProps)(Search);
