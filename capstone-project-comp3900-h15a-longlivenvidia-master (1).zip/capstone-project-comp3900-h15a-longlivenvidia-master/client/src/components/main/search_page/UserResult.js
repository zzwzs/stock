import React from "react";
import styled from "styled-components";


const Usercard = styled.div`
    display: flex;
    flex-direction: row;
    align-items: center;
    margin-top: 20px;
    padding: 2px 20px;
    text-align: left;
    border-radius: 24px;
    transition: 0.25s;
    cursor: pointer;
    &: hover {
      background: ${({ theme }) => theme.secondary};
    }
`;
const Div = styled.div`
    flex:1;
    margin: 0;
`
const Name = styled.p`
    font-size: 2em;
    margin: 0;
`;

const UserResult = ({firstName, lastName, email, onClickaction}) => {
    return (
      <Usercard onClick = {onClickaction}>
        <Div>
          <Name>{firstName}   {lastName}</Name>
        </Div>
        <Div>
          <p>{email}</p>
        </Div>
      </Usercard>
    );
}
  
export default UserResult; 
