import React from "react";
import styled from "styled-components";

const Stockcard = styled.div`
    margin-top: 9px;
    padding: 10px;
    text-align: left;
    border-radius: 24px;
    transition: 0.25s;
    cursor: pointer;
    &: hover {
        background: ${({ theme }) => theme.secondary};
    }
`;

const StockInfo = styled.div`
    display: flex;
    flex-direction: row;
`;

const PriceContainer1 = styled.div`
    display: flex;
    flex-direction: row;
    width: 66%;
    margin: 0;
    padding: 0;
`;

const PriceContainer2 = styled.div`
    display: flex;
    flex-direction: column;
`;

const Img = styled.img`
    float: left;
    height: 4rem;
    margin-right: 10px;
    border-radius: 10%;
`;
const P = styled.p`
    flex: 1;
    font-size: 0.8em;
    margin: 0;
`;
const Symbol = styled.p`
    font-size: 0.8em;
    margin-top: 2px;
    margin-bottom: 8px;
`;

const Footnote = styled.p`
    margin-top: 0;
    font-size: 10px;
    color: grey;
`;
const Div = styled.div`
    flex: 1;
`;
const Span = styled.span`
    color: #ff7edb;
    background: none;
    font-weight: bold;
`;

const H3 = styled.h3`
    margin-top: 8px;
    margin-bottom: 0px;
`;

const Increase = styled.span`
    color: #36ff00;
    background: none;
    font-size: 1.6em;
`;

const Decrease = styled.span`
    color: red;
    background: none;
    font-size: 1.6em;
`;

const Button = styled.button`
    float: right;
    background: none;
    margin: 20px 10px;
    text-align: center;
    border: 2px solid #42a5f5;
    padding: 14px 40px;
    outline: none;
    color: ${({ theme }) => theme.textColor};
    border-radius: 24px;
    transition: 0.25s;
    cursor: pointer;
    &: hover {
        background: #ff7edb;
        border-color: #ff7edb;
    }
`;

const dailychange = (curr, prev) => {
    if (prev === 0) {
        return "-";
    }
    const num = Number(((curr - prev) / prev) * 100).toFixed(3);
    if (num < 0) {
        return <Decrease>{num}%</Decrease>;
    } else {
        return <Increase>+{num}%</Increase>;
    }
};

const dailyprice = (curr, prev) => {
    if (prev === 0) {
        return "-";
    }
    const num = Number(((curr - prev) / prev) * 100).toFixed(3);
    if (num < 0) {
        return <Decrease>${curr}</Decrease>;
    } else {
        return <Increase>${curr}</Increase>;
    }
};

const StockResult = ({ companyName, logo, symbol, price }) => {
    return (
        <Stockcard>
            <Img src={logo} />
            <Button>&#43; Add to Watchlist</Button>
            <StockInfo>
                <Div style={{ flex: 3 }}>
                    <H3>{companyName}</H3>
                    <Symbol>{symbol}</Symbol>
                    {price ? (
                        <div>
                            <PriceContainer1>
                                <P>
                                    <Span>Open</Span> <br /> ${price.popen}
                                </P>
                                <P>
                                    <Span>High</Span> <br /> ${price.phigh}
                                </P>
                                <P>
                                    <Span>Low</Span> <br /> ${price.plow}
                                </P>
                                <P>
                                    <Span>Prev close price</Span> <br /> $
                                    {price.pprev}
                                </P>
                            </PriceContainer1>
                            <Footnote>* Unit Price of the day in USD</Footnote>
                        </div>
                    ) : null}
                </Div>
                {price ? (
                    <Div>
                        <PriceContainer2>
                            <P>
                                <Span>Current price</Span> <br />{" "}
                                {dailyprice(price.pcurr, price.pprev)}
                            </P>{" "}
                            <br />
                            <P>
                                <Span>Daily change</Span> <br />{" "}
                                {dailychange(price.pcurr, price.pprev)}
                            </P>
                        </PriceContainer2>
                    </Div>
                ) : null}
            </StockInfo>
        </Stockcard>
    );
};

export default StockResult;
