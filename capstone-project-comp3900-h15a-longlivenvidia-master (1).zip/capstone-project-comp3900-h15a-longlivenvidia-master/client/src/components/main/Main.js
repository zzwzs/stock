import React from "react";
import styled from "styled-components";
import Error from "./Error";
import Logout from "./logout_page/Logout";
import Settings from "./settings_page/Settings";
import "./style.css";
import Dashboard from "./dashboard_page/Dashboard";
import Watchlist from "./watchlist_page/Watchlist";
import Search from "./search_page/Search";
import { Route } from "react-router-dom/cjs/react-router-dom.min";

const Container = styled.div`
    width: auto;
    margin-left: ${({ sideBarState }) =>
        sideBarState.sideBarOpen
            ? sideBarState.sideBarFullLength
            : sideBarState.sideBarHiddenLength};
    transition: margin-left 0.3s;
    position: relative;
    padding: 0 4rem;
    @media (max-width: 700px) {
        hight: 100%;
        margin-left: ${({ sideBarState }) =>
            sideBarState.sideBarOpen
                ? sideBarState.sideBarHiddenLength
                : sideBarState.sideBarFullLength};
        transition: margin-left 0.3s;
    }
`;

const renderPage = (active) => {
    switch (active) {
        case 0:
            return <Dashboard />;
        case 1:
            return <Search />;
        case 2:
            return <Watchlist />;
        case 3:
            return <Settings />;
        case 4:
            return <Route path="/logout" component={Logout} />;

        default:
            return <Error />;
    }
};

const Main = ({ active, sideBarState }) => {
    return (
        <Container sideBarState={sideBarState}>{renderPage(active)}</Container>
    );
};

export default Main;
