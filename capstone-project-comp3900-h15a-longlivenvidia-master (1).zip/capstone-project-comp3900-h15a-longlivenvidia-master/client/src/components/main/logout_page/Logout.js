import React, { useEffect } from "react";
import { useDispatch } from "react-redux";
import { useSelector } from "react-redux";
import { CSSTransition } from "react-transition-group";
import { logoutUser } from "../../../store/actions/user_actions";

const Logout = (props) => {
    const logout = useSelector((state) => state.user);
    const dispatch = useDispatch();

    useEffect(() => {
        dispatch(logoutUser());
    }, [dispatch]);

    useEffect(() => {
        if (logout.auth === null) {
            setTimeout(() => {
                props.history.push("/login");
            }, 1000);
        }
    }, [logout, props]);

    return (
        <CSSTransition in={true} appear={true} timeout={500} classNames="fade">
            <div>You are logged out</div>
        </CSSTransition>
    );
};

export default Logout;