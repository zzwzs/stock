import React from "react";
import Dashboard from "./containers/Dashboard";
import FrontPage from "./containers/FrontPage";
import { Switch, Route, BrowserRouter } from "react-router-dom";
import Auth from "./hoc/auth";

const App = () => {
    return (
        <BrowserRouter>
            <Switch>
                <Route
                    path="/login"
                    component={Auth((props) => (
                        <FrontPage {...props} />
                    ))}
                />
                <Route
                    path="/"
                    component={Auth((props) => (
                        <Dashboard {...props} />
                    ))}
                />
            </Switch>
        </BrowserRouter>
    );
};

export default App;
