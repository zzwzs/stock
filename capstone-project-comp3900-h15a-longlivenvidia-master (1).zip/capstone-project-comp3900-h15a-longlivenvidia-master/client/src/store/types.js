export const USER_LOGIN = "user_login";
export const USER_AUTH = "user_auth";
export const USER_LOGOUT = "user_logout";
export const USER_REGISTER = "user_register";
export const USER_UPDATE = "user_update";
export const USER_SEARCH = "user_search";
export const SEARCH_STOCK = "search_stock";
export const SEARCH_SYMBOL = "search_symbol";
export const SEARCH_PRICE= "search_price";

