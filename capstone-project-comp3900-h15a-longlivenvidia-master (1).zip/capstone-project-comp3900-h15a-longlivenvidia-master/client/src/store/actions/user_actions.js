import axios from "axios";
import {
    USER_LOGIN,
    USER_AUTH,
    USER_LOGOUT,
    USER_REGISTER,
    USER_UPDATE,
    USER_SEARCH,
} from "../types";

// ========== USER ===========

export function loginUser({ email, password }) {
    const request = axios
        .post("/api/users/login", { email, password })
        .then((response) => response.data);

    return {
        type: USER_LOGIN,
        payload: request,
    };
}

export function auth() {
    const request = axios
        .get("/api/users/auth")
        .then((response) => response.data);

    return {
        type: USER_AUTH,
        payload: request,
    };
}

export function logoutUser() {
    const request = axios.get("/api/users/logout").then((response) => {
        return null;
    });

    return {
        type: USER_LOGOUT,
        payload: request,
    };
}

export function registerUser({ firstName, lastName, email, password }) {
    const request = axios
        .post("/api/users/register", { firstName, lastName, email, password })
        .then((response) => response.data);

    return {
        type: USER_REGISTER,
        payload: request,
    };
}

export function updateUser({ firstName, lastName, email, password }) {
    const request = axios
        .post("/api/users/update", { firstName, lastName, email, password })
        .then((response) => response.data);

    return {
        type: USER_UPDATE,
        payload: request,
    };
}

export function searchUser(emailaddr) {
    const request = axios
        .post("/api/users/search", { email: emailaddr })
        .then((response) => response.data);

    return {
        type: USER_SEARCH,
        payload: request,
    };
}