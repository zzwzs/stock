import axios from "axios";
import {
    SEARCH_STOCK,
    SEARCH_SYMBOL,
    SEARCH_PRICE,
} from "../types";

// ========== SEARCH stocks ===========
export function searchStock (keyword) {
   const request = axios
        .post("/api/finnhub/searchstock", {searchword: keyword} )
        .then((response) => response.data)
    
    return {
        type: SEARCH_STOCK,
        payload: request,
    }; 
}

export function searchPrice (keyword) {
    const request = axios
         .post("/api/finnhub/searchprice", {searchword: keyword} )
         .then((response) => response.data)
     
    return {
        type: SEARCH_PRICE,
        payload: request,
    }; 
 }

// this one implements near match
export function searchSymbol (keyword) {
    const request = axios
         .post("/api/finnhub/searchsymbol", {searchword: keyword} )
         .then((response) => response.data)
     
    return {
        type: SEARCH_SYMBOL,
        payload: request,
    }; 
 }
 