import {
    SEARCH_STOCK,
    SEARCH_SYMBOL,
    SEARCH_PRICE,
} from "../types";

export default function (state = {}, action) {
    switch (action.type) {
        case SEARCH_STOCK:
            return {
                ...state,
                success: action.payload.success,
                search: action.payload.search? action.payload.search : false,
            };
        case SEARCH_SYMBOL:
            return{
                ...state,
                success: action.payload.success,
                search: action.payload.search? action.payload.search : false,
            }
        case SEARCH_PRICE:
            return{
                ...state,
                success: action.payload.success,
                price: action.payload.price? action.payload.price : false,
            }
        default:
            return state;
    }
}
