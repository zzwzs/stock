import { combineReducers } from "redux";
import user from "./user_reducer";
import finnhub from "./finnhub_reducer";

const rootReducer = combineReducers({
    user,
    finnhub,
});

export default rootReducer;
