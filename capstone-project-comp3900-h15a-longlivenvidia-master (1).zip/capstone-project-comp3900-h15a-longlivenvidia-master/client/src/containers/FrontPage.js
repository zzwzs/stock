import React, { Component, useState } from "react";
import styled from "styled-components";
import { createGlobalStyle } from "styled-components";
import SignIn from "../components/users/SignIn";
import SignUp from "../components/users/SignUp";

export const GlobalStyles = createGlobalStyle`
body {
    margin: 0;
    padding: 0;
    font-family: sans-serif;
    background: #34495e;
}
`;

const SignInContainer = styled.div`
  width: 300px;
  padding: 40px;
  position: absolute;
  top: 50%;
  left: 50%;
  border-radius: 9px;
  transform: translate(-50%,-50%);
  background: #191919;
  text-align: centerhadow: 0 50px 70px -20px rgba(0, 0, 0, 0.8);
`;

const FrontPage = (props) => {
    const [hasAccount, setHasAccount] = useState(true);

    return (
        <div>
            <GlobalStyles />
            <SignInContainer>
                {hasAccount ? (
                    <SignIn
                        {...props}
                        hasAccount={hasAccount}
                        setHasAccount={setHasAccount}
                    />
                ) : (
                    <SignUp
                        {...props}
                        hasAccount={hasAccount}
                        setHasAccount={setHasAccount}
                    />
                )}
            </SignInContainer>
        </div>
    );
};

export default FrontPage;
