import React, { useState } from "react";
import Main from "../components/main/Main";
import Navbar from "../components/navbar/Navbar";
import Sidebar from "../components/sidebar/Sidebar";
import { GlobalStyles } from "../styles/global";
import { lightTheme, darkTheme } from "../styles/theme";
import { ThemeProvider } from "styled-components";
import { useThemeContext } from "../components/sidebar/Menu/ToggleSwitch/themeContext";

const Dashboard = (props) => {
    const { theme } = useThemeContext();
    const [active, setActive] = useState(0);
    const [sideBarOpen, setSideBarOpen] = useState(true);
    const sideBarState = {
        sideBarOpen: sideBarOpen,
        setSideBarOpen: setSideBarOpen,
        sideBarFullLength: "13rem",
        sideBarHiddenLength: "4rem",
    };
    return (
        <ThemeProvider theme={theme === "light" ? lightTheme : darkTheme}>
            <GlobalStyles />
            <Sidebar
                active={active}
                activate={setActive}
                sideBarState={sideBarState}
            />
            <Navbar />
            <Main
                active={active}
                activate={setActive}
                sideBarState={sideBarState}
            />
        </ThemeProvider>
    );
};

export default Dashboard;
