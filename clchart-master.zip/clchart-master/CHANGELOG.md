# Change Log

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

<a name="0.1.0"></a>
# [0.1.0](https://github.com/seerline/clchart/compare/v0.0.9...v0.1.0) (2018-09-14)



<a name="0.0.9"></a>
## [0.0.9](https://github.com/seerline/clchart/compare/v0.0.8...v0.0.9) (2018-09-14)


### Bug Fixes

* **webpack:** add bable compile for es5 ([261956b](https://github.com/seerline/clchart/commit/261956b))



<a name="0.0.8"></a>
## [0.0.8](https://github.com/seerline/clchart/compare/v0.0.6...v0.0.8) (2018-09-09)
