/**
 * Copyright (c) 2018-present clchart Contributors.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 *
 */

export const CHART_SUPER = {
  style: 'snapshot', // 'order' || 'snapshot' || 'queue'
  // animate : true,   // 
}

